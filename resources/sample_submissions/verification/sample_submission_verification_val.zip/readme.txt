Extra Data [1] / No Extra Data [0] : 0
Description : This submission was made a sample package for participants to reference. Verification accuracies for 7 categories are .5 (i.e., 50.0 percent).